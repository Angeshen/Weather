"""
Flask web dashboard for the Kalshi Weather Trading Bot.
Provides a GUI to monitor, scan, and control the bot.
"""

import threading
import time
from datetime import datetime, timezone

from flask import Flask, jsonify, render_template, request

from src.config import settings
from src.data.kalshi_client import KalshiClient
from src.data.market_scanner import scan_weather_markets, scan_weather_markets_public
from src.data.weather import get_forecast_for_city
from src.core.edge_calculator import evaluate_market
from src.core.trade_executor import (
    execute_trade,
    get_current_bankroll,
    get_trade_history,
    get_stats,
    get_bankroll_history,
    get_settled_trades,
    update_trade_note,
    log_bankroll,
    init_db,
    get_open_trade_count,
)
from src.core.notifications import (
    notify_bot_status,
    notify_daily_summary,
    notify_scan_summary,
    notify_settlement,
    test_notification,
)
from src.core.settlement import settle_open_trades
from src.core.backtest import run_backtest, get_backtest_progress

app = Flask(
    __name__,
    template_folder="templates",
    static_folder="static",
)

# Bot state
bot_state = {
    "running": False,
    "thread": None,
    "last_scan": None,
    "last_signals": [],
    "last_markets": [],
    "scan_count": 0,
}


def run_scan():
    """Run a single scan and return signals."""
    client = None
    if settings.trading_mode == "live":
        try:
            client = KalshiClient()
        except Exception:
            pass

    try:
        if settings.trading_mode == "live" and client:
            markets = scan_weather_markets(client)
        else:
            markets = scan_weather_markets_public()
    except Exception as e:
        return [], [], str(e)

    bankroll = get_current_bankroll()
    signals = []

    for market in markets:
        try:
            forecast = get_forecast_for_city(
                series_ticker=market["series_ticker"],
                target_date=market["target_date"],
                threshold_f=market["threshold_f"],
            )
            if forecast.get("error"):
                continue

            signal = evaluate_market(market, forecast, bankroll)
            if signal:
                signals.append(signal)
        except Exception:
            continue

    signals.sort(key=lambda s: s["edge"], reverse=True)

    if client:
        client.close()

    # Strip raw_market (not JSON serializable)
    clean_markets = []
    for m in markets:
        cm = {k: v for k, v in m.items() if k != "raw_market"}
        clean_markets.append(cm)

    return signals, clean_markets, None


def bot_loop():
    """Background bot loop."""
    init_db()
    log_bankroll(get_current_bankroll(), "Bot started via GUI")

    client = None
    if settings.trading_mode == "live":
        try:
            client = KalshiClient()
        except Exception:
            pass

    while bot_state["running"]:
        try:
            if settings.trading_mode == "live" and client:
                markets = scan_weather_markets(client)
            else:
                markets = scan_weather_markets_public()

            bankroll = get_current_bankroll()
            signals = []

            for market in markets:
                try:
                    forecast = get_forecast_for_city(
                        series_ticker=market["series_ticker"],
                        target_date=market["target_date"],
                        threshold_f=market["threshold_f"],
                    )
                    if forecast.get("error"):
                        continue
                    signal = evaluate_market(market, forecast, bankroll)
                    if signal:
                        signals.append(signal)
                except Exception:
                    continue

            signals.sort(key=lambda s: s["edge"], reverse=True)

            # Execute trades
            executed = 0
            for signal in signals:
                if executed >= settings.max_concurrent_trades:
                    break
                result = execute_trade(signal, client)
                if result.get("status") not in ("blocked", "failed"):
                    executed += 1

            # Check for settlements every scan
            try:
                settle_results = settle_open_trades()
                if settle_results.get("settled", 0) > 0:
                    notify_settlement(settle_results)
            except Exception:
                pass

            # Update state
            clean_markets = [{k: v for k, v in m.items() if k != "raw_market"} for m in markets]
            bot_state["last_scan"] = datetime.now(timezone.utc).isoformat()
            bot_state["last_signals"] = signals
            bot_state["last_markets"] = clean_markets
            bot_state["scan_count"] += 1

        except Exception:
            pass

        # Sleep in small increments so we can stop quickly
        for _ in range(settings.scan_interval_seconds):
            if not bot_state["running"]:
                break
            time.sleep(1)

    if client:
        client.close()


# --- Routes ---

@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/api/status")
def api_status():
    return jsonify({
        "running": bot_state["running"],
        "mode": settings.trading_mode,
        "last_scan": bot_state["last_scan"],
        "scan_count": bot_state["scan_count"],
        "scan_interval": settings.scan_interval_seconds,
    })


@app.route("/api/stats")
def api_stats():
    return jsonify(get_stats())


@app.route("/api/trades")
def api_trades():
    limit = request.args.get("limit", 50, type=int)
    return jsonify(get_trade_history(limit))


@app.route("/api/scan", methods=["POST"])
def api_scan():
    """Run a manual scan."""
    signals, markets, error = run_scan()
    bot_state["last_scan"] = datetime.now(timezone.utc).isoformat()
    bot_state["last_signals"] = signals
    bot_state["last_markets"] = markets
    bot_state["scan_count"] += 1
    return jsonify({
        "signals": signals,
        "markets_count": len(markets),
        "error": error,
    })


@app.route("/api/signals")
def api_signals():
    return jsonify(bot_state["last_signals"])


@app.route("/api/markets")
def api_markets():
    return jsonify(bot_state["last_markets"])


@app.route("/api/bot/start", methods=["POST"])
def api_bot_start():
    if bot_state["running"]:
        return jsonify({"status": "already_running"})

    bot_state["running"] = True
    bot_state["thread"] = threading.Thread(target=bot_loop, daemon=True)
    bot_state["thread"].start()
    notify_bot_status("started")
    return jsonify({"status": "started"})


@app.route("/api/bot/stop", methods=["POST"])
def api_bot_stop():
    bot_state["running"] = False
    notify_bot_status("stopped")
    return jsonify({"status": "stopped"})


@app.route("/api/config")
def api_config():
    return jsonify({
        "trading_mode": settings.trading_mode,
        "initial_bankroll": settings.initial_bankroll,
        "max_trade_size": settings.max_trade_size,
        "daily_loss_limit": settings.daily_loss_limit,
        "max_concurrent_trades": settings.max_concurrent_trades,
        "min_edge_threshold": settings.min_edge_threshold,
        "kelly_fraction": settings.kelly_fraction,
        "scan_interval_seconds": settings.scan_interval_seconds,
        "weather_series": settings.weather_series,
    })


@app.route("/api/mode", methods=["POST"])
def api_set_mode():
    """Switch between paper and live trading mode."""
    data = request.get_json() or {}
    new_mode = data.get("mode", "").lower()
    if new_mode not in ("paper", "live"):
        return jsonify({"error": "Mode must be 'paper' or 'live'"}), 400

    settings.trading_mode = new_mode
    return jsonify({"trading_mode": settings.trading_mode})


@app.route("/api/equity")
def api_equity():
    """Get equity curve data."""
    bankroll = get_bankroll_history(200)
    settled = get_settled_trades()
    return jsonify({"bankroll_history": bankroll, "settled_trades": settled})


@app.route("/api/backtest", methods=["POST"])
def api_backtest():
    """Run a historical backtest."""
    data = request.get_json() or {}
    days = data.get("days", 30)
    days = min(max(int(days), 7), 90)
    results = run_backtest(days)
    return jsonify(results)


@app.route("/api/backtest/progress")
def api_backtest_progress():
    """Get live backtest progress."""
    return jsonify(get_backtest_progress())


@app.route("/api/trade/note", methods=["POST"])
def api_trade_note():
    """Save a note on a trade."""
    data = request.get_json() or {}
    trade_id = data.get("trade_id")
    note = data.get("note", "")
    if not trade_id:
        return jsonify({"error": "trade_id required"}), 400
    update_trade_note(int(trade_id), note)
    return jsonify({"status": "saved"})


@app.route("/api/settle", methods=["POST"])
def api_settle():
    """Manually trigger settlement check."""
    results = settle_open_trades()
    if results.get("settled", 0) > 0:
        notify_settlement(results)
    return jsonify(results)


@app.route("/api/telegram/test", methods=["POST"])
def api_telegram_test():
    """Send a test message to verify Telegram is configured."""
    success = test_notification()
    if success:
        return jsonify({"status": "sent"})
    return jsonify({"error": "Failed — check TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env"}), 400


@app.route("/api/telegram/daily", methods=["POST"])
def api_telegram_daily():
    """Manually trigger a daily summary notification."""
    stats = get_stats()
    notify_daily_summary(stats)
    return jsonify({"status": "sent", "stats": stats})


# Daily summary scheduler thread
def _daily_summary_loop():
    """Send a daily summary at the configured local time (hour:minute)."""
    import time as _time
    last_sent_date = None
    while True:
        now = datetime.now()  # local time
        today = now.strftime("%Y-%m-%d")
        target_hour = settings.telegram_daily_summary_hour
        target_minute = settings.telegram_daily_summary_minute
        if now.hour == target_hour and now.minute == target_minute and last_sent_date != today:
            stats = get_stats()
            notify_daily_summary(stats)
            last_sent_date = today
        _time.sleep(30)


# Start daily summary thread if Telegram is configured
if settings.telegram_bot_token and settings.telegram_chat_id:
    _daily_thread = threading.Thread(target=_daily_summary_loop, daemon=True)
    _daily_thread.start()
